const express = require("express");
const bodyParser = require("body-parser");
const handlebars = require("express-handlebars").engine;
const post = require("./models/post");

const app = express();
const PORT = 8081;

app.engine("handlebars", handlebars({ defaultLayout: "main" }));
app.set("view engine", "handlebars");

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.get("/", homeRoute);
app.get("/consulta", consultaRoute);
app.post("/cadastrar", cadastrarRoute);

function homeRoute(req, res) {
  res.render("primeira_pagina");
}

function consultaRoute(req, res) {
  post
    .findAll()
    .then(function (posts) {
      res.render("consulta", { post: posts });
    })
    .catch(function (error) {
      console.log("Erro ao carregar dados do banco: " + error);
      res.status(500).send("Erro ao carregar dados do banco");
    });
}

function cadastrarRoute(req, res) {
  const newPost = {
    nome: req.body.nome,
    telefone: req.body.telefone,
    origem: req.body.origem,
    data_contato: req.body.data_contato,
    observacao: req.body.observacao,
  };

  post
    .create(newPost)
    .then(function () {
      res.redirect("/");
    })
    .catch(function (error) {
      console.log("Falha ao cadastrar os dados: " + error);
      res.status(400).send("Falha ao cadastrar os dados");
    });
}

function startServer() {
  app.listen(PORT, function () {
    console.log("Servidor ativo na porta " + PORT);
  });
}

startServer();
